% runAnalysis performs analysis of example spike count data using the
%   modulated Poisson model presented in Goris, Movshon & Simoncelli (2014)
%   It requires the following files to be located in the same folder:
%   'exampleCell1.mat', 'examplePopulation.mat', 'fitModPoissModel'

% Begin with clean slate
clear all
close all
clc

% Run analysis for single cell
T = fitModPoissModel('exampleCell1');


% Visualize model fit
load('exampleCell1')
ss                = get(0, 'screensize');
[mu, iM]          = max(T.exp.countMean);
r                 = 1./T.fit.sigG2;
p                 = r./(r + mu);
N                 = 0:1:80;
nB                = nbinpdf(N, r, p);
[freq, binCenter] = hist(S.spikeCounts(S.condVec == T.exp.stimValue(iM)), 0:5:80);
prob              = freq/sum(freq* diff(binCenter(1:2)));

meanTemp = logspace(log10(min(T.exp.countMean(T.exp.countMean ~= 0))), log10(max(T.exp.countMean)), 100);
varPred  = meanTemp + T.fit.sigG2*meanTemp.^2;


set(figure(1), 'OuterPosition', ss)
subplot(1,3,1)
plot(N, nB, 'r-', 'linewidth', 2)
bar(binCenter, prob, 1, 'b')
hold on, box off, axis square
plot(N, nB, 'r-', 'linewidth', 2)
axis([-10 100 0 1.15*max([nB(:); prob(:)])])
title('One stimulus condition')
xlabel('Spike count')
ylabel('Probability')

subplot(1,3,2)
if  strcmp(S.area, 'LGN')
    semilogx(T.exp.stimValue, T.exp.stimResp, 'r-', 'linewidth', 2)
    hold on, box off, axis square
    semilogx(T.exp.stimValue, T.exp.stimResp, 'ko', 'markersize', 12, 'markerfacecolor', [0 .5 1])
    axis([.01 100 -5 1.25*max(T.exp.stimResp(:))])
    xlabel('Spatial frequency (c/deg)')
else
    plot(T.exp.stimValue, T.exp.stimResp, 'r-', 'linewidth', 2)
    hold on, box off, axis square
    plot(T.exp.stimValue, T.exp.stimResp, 'ko', 'markersize', 12, 'markerfacecolor', [0 .5 1])
    axis([-40 400 -5 1.25*max(T.exp.stimResp(:))])
    xlabel('Drift direction (deg)')
end

ylabel('Mean firing rate (ips)')
legend('Model', 'Data', 'Location', 'NorthWest')

subplot(1,3,3)
loglog(meanTemp, varPred, 'r-', 'linewidth', 2)
hold on, box off, axis square
loglog(T.exp.countMean, T.exp.countVar, 'ko', 'markersize', 12, 'markerfacecolor', [0 .5 1])
loglog([.01 1000], [.01 1000], 'k--')
axis([.01 1000 .01 1000])
legend('Model', 'Data', 'Location', 'NorthWest')
xlabel('Mean count (spikes)')
ylabel('Variance count (spikes^2)')
drawnow


% Run analysis for population of cells
S = fitModPoissModel('examplePopulation');

% Visualize model fit
iList      = [1 2 3 4 5 6];
jList      = [1 1 1 1 1 1];
varPredPop = repmat(meanTemp, [6, 1]) + S.fit.sigG2'*meanTemp.^2;

set(figure(2), 'OuterPosition', ss)
subplot(7, 7, 19)
plot(-50, 0, 'r.')
hold on, box off, axis square
plot(-50, 0, 'b.')
axis([-40 400 -1 1])
legend('Model', 'Data')
xlabel('Drift direction (deg)')
ylabel('Response correlation')

for iU = iList
    for jU = jList
        subplot(7, 7, iU+43)
        plot(S.exp.stimValue, S.exp.stimResp(iU,:), 'b-')
        hold on, box off, axis square
        axis([-40 400 -5 30])
        
        subplot(7, 7, (7*(iU-1)) + jU)
        plot(S.exp.stimValue, S.exp.stimResp(iU,:), 'b-')
        hold on, box off, axis square
        axis([-40 400 -5 30])
    end
end


for iU = 1:6
    for jU = 1:6
        if (iU > jU)
            subplot(7, 7, 7*(iU-1) + 1 + jU)
            plot(S.exp.stimValue, squeeze(S.exp.countCorr(iU,jU,:)), 'b.')
            hold on, box off, axis square
            plot(S.exp.stimValue, squeeze(S.fit.corr.pred(iU,jU,:)), 'r-', 'linewidth', 2)
            axis([-40 400 -1 1])
        end
    end
end



set(figure(3), 'OuterPosition', ss)
subplot(7, 7, 19)
semilogx(.01, 0, 'r.')
hold on, box off, axis square
semilogx(.01, 0, 'b.')
axis([.25 25 -1 1])
legend('Model', 'Data')
xlabel('Geometric mean response')
ylabel('Response correlation')

for iU = iList
    for jU = jList
        
        meanTemp   = logspace(log10(min(S.exp.countMean(iU,:))), log10(max(S.exp.countMean(iU,:))), 100);
        varPredPop = meanTemp + S.fit.sigG2(iU)*meanTemp.^2;
        
        subplot(7, 7, iU+43)
        loglog(S.exp.countMean(iU,:), S.exp.countVar(iU,:), 'b.')
        hold on, box off, axis square
        loglog(meanTemp, varPredPop, 'r-', 'linewidth', 2)
        loglog([.1 100], [.1 100], 'k--')
        axis([.1 100 .1 100])
        
        subplot(7, 7, (7*(iU-1)) + jU)
        loglog(S.exp.countMean(iU,:), S.exp.countVar(iU,:), 'b.')
        hold on, box off, axis square
        loglog(meanTemp, varPredPop, 'r-', 'linewidth', 2)
        loglog([.1 100], [.1 100], 'k--')
        axis([.1 100 .1 100])
    end
end


for iU = 1:6
    for jU = 1:6
        if (iU > jU)
            
            respGeo = geomean([max(.01, S.exp.countMean(iU,:)); max(.01, S.exp.countMean(jU,:))]);
            
            subplot(7, 7, 7*(iU-1) + 1 + jU)
            semilogx(respGeo, squeeze(S.exp.countCorr(iU,jU,:)), 'b.')
            hold on, box off, axis square
            semilogx(respGeo, squeeze(S.fit.corr.pred(iU,jU,:)), 'r.')
            axis([.25 25 -1 1])
        end
    end
end






