%% This script clarifies the data format by means of simulated data
%%

% Begin with clean slate
clear all
close all
clc


%% Constants to play with -- number of neurons, trials, and conditions
nNeurons    = 5;
nTrials     = 100;
nConditions = 10;
trialDur    = 1000; % in ms
%%


%% Don't touch this
% Sample condition vector (size: Tx1)
condVec = randsample(nConditions, nTrials, 1);

% Sample neural selectivity (size: Nx1)
condPref = nConditions*rand(nNeurons, 1);
respGain = 100*rand(nNeurons, 1);

% Compute expected spike rate for every neuron in every condition
respRate = repmat(respGain', [nTrials 1]).*((1 - (1/nConditions)*abs(repmat(condVec, [1 nNeurons]) - repmat(condPref', [nTrials 1])))).^4;

% Simulate spike trains
randNumbers = rand(nTrials, nNeurons, trialDur);
spikeMat    = randNumbers < repmat(respRate/1000, [1 1 trialDur]);
spikeCounts = sum(spikeMat, 3)';

for iT = 1:nTrials
    for iN = 1:nNeurons
        spikeTimes{iN}{iT} = find(spikeMat(iT,iN,:) == 1);
    end
end
%%

%% Store everything in a structure -- this is the data format
S.condVec     = condVec;                    % size: Tx1
S.trialDur    = trialDur + 0*condVec;       % size: Tx1, trial duration in msec
S.whatever    = [];                         % size: Tx1, useful information that has single-trial resolution, e.g., choice behavior in a 2AFC-paradigm
S.spikeCounts = spikeCounts;                % size: NxT 
S.spikeTimes  = spikeTimes;                 % size: NxT cell array
%%


%% Process and plot data
% Get response mean and variance
cond = unique(S.condVec);
for iC = 1:numel(cond)
   meanRate(:,iC)  = mean(S.spikeCounts(:, S.condVec == cond(iC))./repmat(S.trialDur(S.condVec == cond(iC))'/1000, [size(S.spikeCounts, 1) 1]), 2);     
   meanCount(:,iC) = mean(S.spikeCounts(:, S.condVec == cond(iC)), 2);     
   varCount(:,iC)  = var(S.spikeCounts(:, S.condVec == cond(iC)), [], 2);     
end
    

figure(1), subplot(1,3,1)
plot([0 1000; 0 1000], [1 1; size(S.spikeCounts, 1) size(S.spikeCounts, 1)],  'k--')
hold on, box off, axis square, axis off
for iN = 1:size(S.spikeCounts, 1)
    if S.spikeCounts(iN, 1) > 0
        plot(S.spikeTimes{iN}{1}, iN, 'ro', 'markersize', 2)
    end
end
title('Spike raster (trial 1)', 'fontsize', 16)

figure(1), subplot(1,3,2)
hold on, box off, axis square
plot(cond, meanRate', 'linewidth', 2)
xlabel('Stimulus condition', 'fontsize', 16)
ylabel('Response mean (ips)', 'fontsize', 16)


figure(1), subplot(1,3,3)
loglog([.1 1000], [.1 1000], 'k--')
hold on, box off, axis square
loglog(meanCount', varCount', 'o')
axis([.1 1000 .1 1000])
xlabel('Response mean (spikes)', 'fontsize', 16)
ylabel('Response variance (spikes^2)', 'fontsize', 16)




